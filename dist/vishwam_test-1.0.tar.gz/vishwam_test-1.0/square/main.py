def main():
    number = int(input("Enter number (Only positive integer is allowed)"))
    print(f'{number} square is {number ** 2}')


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()
